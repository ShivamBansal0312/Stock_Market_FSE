export interface MailVerifyModel{
    code:string;
}