import { TestBed } from '@angular/core/testing';

import { MailVerifyService } from './mail-verify.service';

describe('MailVerifyService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MailVerifyService = TestBed.get(MailVerifyService);
    expect(service).toBeTruthy();
  });
});
