import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { loginModel } from "src/app/login/loginModel";

type EntityResponseType = HttpResponse<loginModel[]>;

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(private http:HttpClient) { }

  getAllUserDetails():Observable<EntityResponseType>{
        return this.http.get<loginModel[]>("http://localhost:5515/UserDatabases", {observe: 'response'});
  }

  saveUserDetails(loginPageModeln:loginModel){
    return this.http.post<loginModel>("http://localhost:5515/UserDatabase", loginPageModeln, {observe: 'response'});
}

}