import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-bar-chart2',
  templateUrl: './my-bar-chart2.component.html',
  styleUrls: ['./my-bar-chart2.component.css']
})
export class MyBarChart2Component implements OnInit {

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true
  };

  public barChartLabels = ['2013', '2014', '2015', '2016', '2017', '2018', '2019'];
  public barChartType = 'bar';
  public barChartLegend = true;

  public barChartData = [
    {data: [83, 59, 80, 81, 56, 55, 40], label: 'TCS'},
    {data: [55, 48, 72, 88, 48, 58, 50], label: 'WIPRO'}
  ];

  constructor() { }

  ngOnInit() {
  }

}
