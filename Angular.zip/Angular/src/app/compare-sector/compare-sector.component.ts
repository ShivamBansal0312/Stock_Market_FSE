import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compare-sector',
  templateUrl: './compare-sector.component.html',
  styleUrls: ['./compare-sector.component.css']
})
export class CompareSectorComponent implements OnInit {

  public pieChartLabels:string[] = ['Technology','Telecom','Real State','Financial'];
  public pieChartData:number[] = [30,20,20,30];
  public pieChartType:string = 'pie';

  constructor() { }

  ngOnInit() {
  }

}
