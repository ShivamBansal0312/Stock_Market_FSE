import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-land',
  templateUrl: './user-land.component.html',
  styleUrls: ['./user-land.component.css']
})
export class UserLandComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
