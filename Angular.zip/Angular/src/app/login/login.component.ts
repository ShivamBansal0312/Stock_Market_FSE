import { Component, OnInit, Output } from '@angular/core';
import {loginModel} from 'src/app/login/loginModel';
import {LoginService} from 'src/app/login/login.service'
import {FormGroup, FormControl} from '@angular/forms';
import {Router} from '@angular/router';
import {element} from 'protractor';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userDetails:loginModel[];
  myForm:FormGroup;

  constructor(private service:LoginService,private router:Router) { }

  ngOnInit():void {
    this.service.getAllUserDetails().subscribe(data => {
      this.userDetails = data.body;
      console.log(data.body)
    });
  
    {
      this.myForm = new FormGroup({
        name: new FormControl(''),
        action: new FormControl('')
      });
    }
  }

  onSubmit(form : FormGroup){
    var k=0;
    for(var i=0;i<this.userDetails.length;i++){
      if(this.userDetails[i].username==form.value.name &&
        this.userDetails[i].password==form.value.action &&
        this.userDetails[i].confirmation=="confirmed"){
          k=1;
          if(this.userDetails[i].usertype=="admin"){this.router.navigate(['/adminland']);break;}
          if(this.userDetails[i].usertype=="user"){this.router.navigate(['/userland']);break;}
        }
    }
    if(k==0){
      alert("Incorrect username or password");
    }
  }

}
