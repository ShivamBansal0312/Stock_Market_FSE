import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyBarChart3Component } from './my-bar-chart3.component';

describe('MyBarChart3Component', () => {
  let component: MyBarChart3Component;
  let fixture: ComponentFixture<MyBarChart3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyBarChart3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyBarChart3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
