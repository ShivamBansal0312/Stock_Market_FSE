export interface ManageExchangeModel{
    id:number;
    stock_exchange:string;
    brief:number;
    contact_address:string;
    remarks:string
}