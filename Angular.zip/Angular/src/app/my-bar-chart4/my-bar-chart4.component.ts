import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-bar-chart4',
  templateUrl: './my-bar-chart4.component.html',
  styleUrls: ['./my-bar-chart4.component.css']
})
export class MyBarChart4Component implements OnInit {

  public barChartOptions = {
    scaleShowVerticalLines: false,
    responsive: true
  };

  public barChartLabels = ['2013', '2014', '2015', '2016', '2017', '2018', '2019'];
  public barChartType = 'bar';
  public barChartLegend = true;

  public barChartData = [
    {data: [65, 58, 62, 88, 88, 58, 80], label: 'INFOSYS'},
    {data: [85, 48, 82, 78, 86, 47, 90], label: 'CTS'}
  ];

  constructor() { }

  ngOnInit() {
  }

}
