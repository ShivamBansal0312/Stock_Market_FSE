import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpEvent, HttpRequest } from '@angular/common/http';
import { Observable, from } from 'rxjs';
import { ExcelModel } from 'src/app/import-data/ExcelModel';
import { ExcelInfoModel } from 'src/app/import-data/ExcelInfoModel'

type EntityResponseType = HttpResponse<ExcelModel[]>;
type EntityResponseType2 = HttpResponse<ExcelInfoModel[]>;

@Injectable({
  providedIn: 'root'
})
export class ImportExcelService {

  constructor(private http:HttpClient) { }
  getAllDetails():Observable<EntityResponseType>{
    return this.http.get<ExcelModel[]>("http://localhost:5512/stockPriceDetail", {observe: 'response'});
}

getAllinfo():Observable<EntityResponseType2>{
  return this.http.get<ExcelInfoModel[]>("http://localhost:5512/info", {observe: 'response'});
}

pushFileToStorage(file: File): Observable<HttpEvent<{}>> {
  const formdata: FormData = new FormData();
  formdata.append('file', file);
  const req = new HttpRequest('POST', 'http://localhost:5512/import', formdata, {
    reportProgress: true,
    responseType: 'text'
  }
  );
  return this.http.request(req);
}

}
