import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyBarChart1Component } from './my-bar-chart1.component';

describe('MyBarChart1Component', () => {
  let component: MyBarChart1Component;
  let fixture: ComponentFixture<MyBarChart1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyBarChart1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyBarChart1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
