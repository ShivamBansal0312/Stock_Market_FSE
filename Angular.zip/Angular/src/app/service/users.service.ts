import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private http: HttpClient) { }

  getUserList() {
    let headers = new HttpHeaders();
    headers.set('Content-Type', 'application/json');

    return this.http.get('/src/app/data/users.json', { headers });
}
}
